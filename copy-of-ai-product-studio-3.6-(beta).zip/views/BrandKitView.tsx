import React from 'react';
import { BrandKitPanel } from '../components/BrandKitPanel';

const BrandKitView: React.FC = () => {
    return <BrandKitPanel />;
};

export default BrandKitView;
