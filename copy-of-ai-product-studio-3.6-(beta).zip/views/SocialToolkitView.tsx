import React from 'react';
import { SocialToolkit } from '../components/SocialToolkit';

const SocialToolkitView: React.FC = () => {
    return <SocialToolkit />;
};

export default SocialToolkitView;
