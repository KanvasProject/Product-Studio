import React from 'react';
import { CampaignPlanner } from '../components/CampaignPlanner';

const CampaignPlannerView: React.FC = () => {
    return <CampaignPlanner />;
};

export default CampaignPlannerView;
